# Travel-kenya-website
This is a web application were one can view various tour attractions in Kenya and they can book their ticket 

# Table of contents
* Home
* Book
* Packages
* About 

# Home
In the home page the companies services are outlined and the company details are stated.

# About 
In the about page the companies privilege are stated and our past customers have rated our services.

# Packges
In this page one loos at the various destination one may want to visit.

# Book
In this page after you have selected your place of tour you can fill in your details and book a ticket.


# Tech stack
 * Tech-stack
  * Php-A programming language that I have used to connct the files and the database.
  * Html-Hypertext Markup Language, and it is the most widely used language to write Web Pages.
  * Css-Cascading Style Sheets (CSS) is a stylesheet language used to describe the presentation of a document written in HTML.
  * MySql-Used it as a local storing databas.
  * Javascript-A programming language tha t makes the we application more responsive.
  * Xampp-An application that comes with both MYSQL and Php.
#Netlify link
* https://travel-kenya.netlify.app/home.html

![image](https://user-images.githubusercontent.com/107704648/231266513-0196e672-b92d-48cd-8270-c5738b13d4b2.png)
![image](https://user-images.githubusercontent.com/107704648/231266608-3085acbe-8bd3-409d-9d86-8e9592776b65.png)
![image](https://user-images.githubusercontent.com/107704648/231266906-f2a2c925-f8c5-4804-a0fe-f15613568cd2.png)
![image](https://user-images.githubusercontent.com/107704648/231266978-acf5b367-ec4d-475d-9eee-83bbe31e4308.png)


